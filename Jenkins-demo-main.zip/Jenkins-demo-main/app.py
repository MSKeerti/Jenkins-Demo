def add(a, b):
    return a - b

if __name__ == "__main__":
    print("5 + 3 =", add(5, 3))
